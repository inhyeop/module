using UnityEngine;

public class PlayerAnimator : MonoBehaviour
{
    [SerializeField]
    private GameObject attackCollision;
    private Animator animator;

    private void Awake()
    {
        animator = GetComponent<Animator>();
    }

    //�ִϸ��̼� ��Ʈ�ѷ� �� ������ �Ķ���� �� Ʈ���� �ߵ� ���� ��ũ��Ʈ
    public void OnMovement(float horizontal, float vertical)
    {
        animator.SetFloat("Horizontal", horizontal);
        animator.SetFloat("Vertical", vertical);
    }

    public void OnJump()
    {
        animator.SetTrigger("OnJump");
    }

    public void Kick()
    {
        animator.SetTrigger("Kick");
    }

    public void ComboAttack()
    {
        animator.SetTrigger("ComboAttack");
    }

    public void OnAttackCollision()
    {
        attackCollision.SetActive(true);
    }
}

